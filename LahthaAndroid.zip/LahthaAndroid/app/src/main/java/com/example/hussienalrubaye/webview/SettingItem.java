package com.example.hussienalrubaye.webview;

/**
 * Created by hussienalrubaye on 9/22/15.
 */
public class SettingItem {

    public  String Name;
    public  int ImageURL;

    public  SettingItem (String Name,int ImageURL){
        this.Name=Name;
        this.ImageURL=ImageURL;
    }
}
