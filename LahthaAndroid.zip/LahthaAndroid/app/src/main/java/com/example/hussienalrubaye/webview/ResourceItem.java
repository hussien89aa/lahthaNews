package com.example.hussienalrubaye.webview;



/**
 * Created by hussienalrubaye on 9/16/15.
 */
public class ResourceItem {
    public  String Name;
    public  int ID;
public  String ImageLink;
    public  ResourceItem (String Name,int ID, String ImageLink){
        this.Name=Name;
        this.ID=ID;
this.ImageLink=ImageLink;
    }
}
